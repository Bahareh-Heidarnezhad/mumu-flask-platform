from flask import Blueprint, render_template, request, flash, redirect, url_for, session, jsonify
from db import get_db
from datetime import datetime
from notification import create_system_notification
from message import send_system_message
from bson import ObjectId

booking_bp = Blueprint('booking', __name__)

@booking_bp.route('/booking', methods=['GET', 'POST'])
def booking():
    """Handle service booking"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    if request.method == 'POST':
        service_type = request.form.get('service_type')
        booking_date = request.form.get('booking_date')
        booking_time = request.form.get('booking_time')
        provider_id = request.form.get('provider_id')  # ID of service provider
        
        if not all([service_type, booking_date, booking_time, provider_id]):
            flash('All fields are required', 'error')
            return render_template('Booking and Reviews.html')
        
        try:
            db = get_db()
            bookings_collection = db['Bookings']
            
            new_booking = {
                'user_id': session['user_id'],
                'provider_id': provider_id,
                'service_type': service_type,
                'booking_date': booking_date,
                'booking_time': booking_time,
                'status': 'pending',
                'created_at': datetime.now()
            }
            
            result = bookings_collection.insert_one(new_booking)
            
            # Create notification for service provider
            notification_message = f"New booking request for {service_type} on {booking_date} at {booking_time}"
            create_system_notification(provider_id, notification_message, 'booking')
            
            flash('Booking created successfully!', 'success')
            return redirect(url_for('booking.my_bookings'))
            
        except Exception as e:
            flash('An error occurred while creating the booking', 'error')
            return render_template('Booking and Reviews.html')
    
    # Initialize empty booking for the template
    booking = {
        '_id': None,
        'service_type': '',
        'booking_date': '',
        'booking_time': '',
        'status': 'pending'
    }
    
    return render_template('Booking and Reviews.html', booking=booking)

@booking_bp.route('/my-bookings')
def my_bookings():
    """View user's bookings"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    db = get_db()
    bookings_collection = db['Bookings']
    
    # Get both bookings made by user and bookings for user's services
    user_bookings = list(bookings_collection.aggregate([
        {
            '$match': {
                '$or': [
                    {'user_id': session['user_id']},
                    {'provider_id': session['user_id']}
                ]
            }
        },
        {
            '$lookup': {
                'from': 'Profiles',
                'localField': 'provider_id',
                'foreignField': 'user_id',
                'as': 'provider'
            }
        },
        {
            '$lookup': {
                'from': 'Profiles',
                'localField': 'user_id',
                'foreignField': 'user_id',
                'as': 'client'
            }
        },
        {'$sort': {'created_at': -1}}
    ]))
    
    return render_template('Booking and Reviews.html', bookings=user_bookings)

@booking_bp.route('/booking/<booking_id>/status', methods=['POST'])
def update_booking_status(booking_id):
    """Update booking status (accept/reject)"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    new_status = request.form.get('status')
    if new_status not in ['accepted', 'rejected', 'completed']:
        flash('Invalid status', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    try:
        db = get_db()
        bookings_collection = db['Bookings']
        
        booking = bookings_collection.find_one({
            '_id': booking_id,
            'provider_id': session['user_id']
        })
        
        if not booking:
            flash('Booking not found', 'error')
            return redirect(url_for('booking.my_bookings'))
        
        bookings_collection.update_one(
            {'_id': booking_id},
            {'$set': {'status': new_status}}
        )
        
        # Create notification for client
        notification_message = f"Your booking has been {new_status}"
        create_system_notification(booking['user_id'], notification_message, 'booking')
        
        flash(f'Booking {new_status} successfully', 'success')
        
    except Exception as e:
        flash('An error occurred while updating the booking', 'error')
    
    return redirect(url_for('booking.my_bookings'))

@booking_bp.route('/submit-review/<booking_id>', methods=['POST'])
def submit_review(booking_id):
    """Submit a review for a completed booking"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    review_text = request.form.get('review')
    rating = request.form.get('rating')
    
    if not all([review_text, rating]):
        flash('Review text and rating are required', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    try:
        db = get_db()
        reviews_collection = db['Reviews']
        bookings_collection = db['Bookings']
        
        # Verify booking exists and is completed
        booking = bookings_collection.find_one({'_id': booking_id})
        if not booking or booking['status'] != 'completed':
            flash('Can only review completed bookings', 'error')
            return redirect(url_for('booking.my_bookings'))
        
        new_review = {
            'booking_id': booking_id,
            'user_id': session['user_id'],
            'provider_id': booking['provider_id'],
            'review_text': review_text,
            'rating': int(rating),
            'created_at': datetime.now()
        }
        
        reviews_collection.insert_one(new_review)
        
        # Create notification for service provider
        notification_message = f"New review received for your service"
        create_system_notification(booking['provider_id'], notification_message, 'review')
        
        flash('Review submitted successfully!', 'success')
        
    except Exception as e:
        flash('An error occurred while submitting the review', 'error')
    
    return redirect(url_for('booking.my_bookings'))

@booking_bp.route('/provider/<provider_id>/reviews')
def provider_reviews(provider_id):
    """View reviews for a service provider"""
    db = get_db()
    reviews = list(db['Reviews'].aggregate([
        {
            '$match': {'provider_id': provider_id}
        },
        {
            '$lookup': {
                'from': 'Profiles',
                'localField': 'user_id',
                'foreignField': 'user_id',
                'as': 'reviewer'
            }
        },
        {'$sort': {'created_at': -1}}
    ]))
    
    provider = db['Profiles'].find_one({'user_id': provider_id})
    
    return render_template('provider_reviews.html', reviews=reviews, provider=provider)

@booking_bp.route('/booking/create', methods=['POST'])
def create_booking():
    """Handle booking creation and send notification message"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'})
    
    try:
        data = request.get_json()
        service_type = data.get('service_type')
        booking_date = data.get('booking_date')
        booking_time = data.get('booking_time')
        
        db = get_db()
        
        # Create new booking
        new_booking = {
            'user_id': session['user_id'],
            'service_type': service_type,
            'booking_date': booking_date,
            'booking_time': booking_time,
            'status': 'pending',
            'created_at': datetime.now()
        }
        
        result = db['Bookings'].insert_one(new_booking)
        
        # Send notification message
        message_text = f"""
            New Booking Confirmation
            Service: {service_type}
            Date: {booking_date}
            Time: {booking_time}
            Status: Pending
            
            Thank you for your booking!
        """
        
        # Add this function to message.py
        send_system_message(session['user_id'], message_text)
        
        return jsonify({
            'success': True,
            'booking_id': str(result.inserted_id)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        })

@booking_bp.route('/submit-review', methods=['POST'])
def submit_review_ajax():
    """Handle review submission via AJAX"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'})
    
    try:
        data = request.get_json()
        review_text = data.get('review_text')
        rating = data.get('rating')
        booking_id = data.get('booking_id')
        
        if not all([review_text, rating, booking_id]):
            return jsonify({'success': False, 'message': 'Missing required fields'})
        
        db = get_db()
        
        # Get booking details
        booking = db['Bookings'].find_one({'_id': ObjectId(booking_id)})
        if not booking:
            return jsonify({'success': False, 'message': 'Booking not found'})
        
        # Create review
        new_review = {
            'booking_id': ObjectId(booking_id),
            'user_id': session['user_id'],
            'provider_id': booking['provider_id'],
            'review_text': review_text,
            'rating': int(rating),
            'created_at': datetime.now()
        }
        
        db['Reviews'].insert_one(new_review)
        
        # Update booking status
        db['Bookings'].update_one(
            {'_id': ObjectId(booking_id)},
            {'$set': {'status': 'reviewed'}}
        )
        
        # Create notification for provider
        notification_message = f"New review received for your service"
        create_system_notification(booking['provider_id'], notification_message, 'review')
        
        return jsonify({
            'success': True,
            'message': 'Review submitted successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        })

@booking_bp.route('/send-request', methods=['POST'])
def send_request():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'})
    
    try:
        data = request.get_json()
        provider_id = data.get('provider_id')
        service_type = data.get('service_type')
        message = data.get('message')
        
        if not all([provider_id, service_type]):
            return jsonify({'success': False, 'message': 'Missing required fields'})
            
        db = get_db()
        
        # Create new request
        new_request = {
            'sender_id': session['user_id'],
            'receiver_id': provider_id,
            'service_type': service_type,
            'message': message,
            'status': 'pending',
            'created_at': datetime.now()
        }
        
        result = db['Requests'].insert_one(new_request)
        
        # Create notification for provider
        notification = {
            'user_id': provider_id,
            'message': f"New service request received for {service_type}",
            'type': 'request',
            'read': False,
            'created_at': datetime.now()
        }
        db['Notifications'].insert_one(notification)
        
        return jsonify({
            'success': True,
            'message': 'Request sent successfully'
        })
        
    except Exception as e:
        print(f"Error sending request: {e}")
        return jsonify({
            'success': False,
            'message': 'Failed to send request'
        })

@booking_bp.route('/view-requests')
def view_requests():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'})
        
    try:
        db = get_db()
        # Get requests received by the user
        received_requests = list(db['Requests'].find({
            'receiver_id': ObjectId(session['user_id'])  # Convert to ObjectId
        }).sort('created_at', -1))
        
        # Get sender details for each request
        for request in received_requests:
            sender = db['Profiles'].find_one({'user_id': str(request['sender_id'])})
            if sender:
                request['sender_name'] = f"{sender.get('first_name', '')} {sender.get('last_name', '')}"
                request['sender_photo'] = sender.get('profile_photo', '')
                request['_id'] = str(request['_id'])  # Convert ObjectId to string for template
        
        return render_template('view_requests.html', requests=received_requests)
        
    except Exception as e:
        print(f"Error viewing requests: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        })

@booking_bp.route('/handle-request/<request_id>/<action>', methods=['POST'])
def handle_request(request_id, action):
    if action not in ['accept', 'reject']:
        return jsonify({'success': False, 'message': 'Invalid action'})
        
    try:
        db = get_db()
        request = db['Requests'].find_one_and_update(
            {'_id': ObjectId(request_id)},
            {'$set': {'status': action}},
            return_document=True
        )
        
        if request:
            # Create notification for sender
            notification = {
                'user_id': request['sender_id'],
                'message': f"Your request has been {action}ed",
                'type': 'request_update',
                'read': False,
                'created_at': datetime.now()
            }
            db['Notifications'].insert_one(notification)
            
            return jsonify({
                'success': True,
                'message': f'Request {action}ed successfully'
            })
            
        return jsonify({
            'success': False,
            'message': 'Request not found'
        })
        
    except Exception as e:
        print(f"Error handling request: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }) 