from flask import Flask, render_template, request, flash, redirect, url_for, session
from login import login_bp
from signup import signup_bp
from hom22 import hom22_bp
from hi import hi_bp
from db import get_db
from datetime import datetime
from profilesetup import profile_bp
from message import message_bp
from notification import notification_bp
from booking import booking_bp
from dashboard import dashboard_bp

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Register the blueprints
app.register_blueprint(login_bp)
app.register_blueprint(signup_bp)
app.register_blueprint(hom22_bp)
app.register_blueprint(hi_bp)
app.register_blueprint(profile_bp)
app.register_blueprint(message_bp)
app.register_blueprint(notification_bp)
app.register_blueprint(booking_bp)
app.register_blueprint(dashboard_bp)

@app.route('/index2')
def index2():
    return render_template('index2.html')

if __name__ == '__main__':
    app.run(debug=True) 