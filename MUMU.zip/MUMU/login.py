from flask import Blueprint, request, render_template, redirect, url_for, flash, session
from werkzeug.security import check_password_hash
from db import get_db

login_bp = Blueprint('login', __name__)

@login_bp.route('/login', methods=['GET', 'POST'])
def login():
    print("login route called")
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        print("username", username)
        print("password", password)
        db = get_db()
        login_collection = db['Login']
        user = login_collection.find_one({'username': username})
        print("user", user)
        if user and check_password_hash(user['password'], password):
            # Store user info in session
            session['user_id'] = str(user['_id'])
            session['username'] = user['username']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard.dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

# Add logout route
@login_bp.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('login.login')) 