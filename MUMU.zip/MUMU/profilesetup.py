from flask import Blueprint, render_template, request, flash, redirect, url_for, session, jsonify
from db import get_db
from datetime import datetime
import os
from werkzeug.utils import secure_filename

profile_bp = Blueprint('profile', __name__)

UPLOAD_FOLDER = 'static/uploads/profile_photos'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@profile_bp.route('/profile-setup', methods=['GET', 'POST'])
def profile_setup():
    """Handle profile setup and updates"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    db = get_db()
    profiles_collection = db['Profiles']
    
    if request.method == 'POST':
        # Get form data
        profile_data = {
            'user_id': session['user_id'],
            'first_name': request.form.get('first_name'),
            'last_name': request.form.get('last_name'),
            'tagline': request.form.get('tagline'),
            'student_email': request.form.get('student_email'),
            'personal_email': request.form.get('personal_email'),
            'skills': request.form.getlist('skills'),
            'categories': request.form.getlist('categories'),
            'social_links': {
                'linkedin': request.form.get('linkedin'),
                'instagram': request.form.get('instagram'),
                'website': request.form.get('website')
            },
            'updated_at': datetime.now()
        }
        
        try:
            # Update existing profile or create new one
            result = profiles_collection.update_one(
                {'user_id': session['user_id']},
                {'$set': profile_data},
                upsert=True
            )
            
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('dashboard.dashboard'))
            
        except Exception as e:
            flash('An error occurred while updating your profile', 'error')
            return render_template('profilesetup.html', profile=profile_data)
    
    # GET request - load existing profile
    profile = profiles_collection.find_one({'user_id': session['user_id']}) or {}
    
    # Define available skills and categories
    available_skills = [
        'Web Development',
        'Photography',
        'Graphic Design',
        'Content Writing',
        'Digital Marketing',
        'Video Editing',
        'Translation',
        'Data Analysis',
        'Teaching/Tutoring',
        'Event Planning'
    ]
    
    available_categories = [
        'Photography',
        'Graphic and Design',
        'Beauty',
        'Food and Catering',
        'Business',
        'Baby Sitting',
        'Cleaning'
    ]
    
    return render_template('profilesetup.html',
                         profile=profile,
                         available_skills=available_skills,
                         available_categories=available_categories)

@profile_bp.route('/profile')
def view_profile():
    """View user profile"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    db = get_db()
    profiles_collection = db['Profiles']
    profile = profiles_collection.find_one({'user_id': session['user_id']})
    
    if not profile:
        flash('Please complete your profile setup', 'info')
        return redirect(url_for('profile.profile_setup'))
    
    return render_template('profile.html', profile=profile)

@profile_bp.route('/upload-profile-picture', methods=['POST'])
def upload_profile_picture():
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401
    
    if 'profile_photo' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['profile_photo']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if file and allowed_file(file.filename):
        try:
            # Create upload directory if it doesn't exist
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            
            # Generate unique filename
            filename = secure_filename(f"{session['user_id']}_{file.filename}")
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            
            # Save file
            file.save(filepath)
            
            # Update database with new photo URL
            db = get_db()
            relative_path = f'/static/uploads/profile_photos/{filename}'
            
            db['Profiles'].update_one(
                {'user_id': session['user_id']},
                {'$set': {'profile_photo': relative_path}},
                upsert=True
            )
            
            return jsonify({
                'success': True,
                'photo_url': relative_path
            })
            
        except Exception as e:
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    return jsonify({
        'success': False,
        'error': 'Invalid file type'
    }), 400 