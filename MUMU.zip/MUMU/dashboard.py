from flask import Blueprint, render_template, request, flash, redirect, url_for, session
from db import get_db
from bson.objectid import ObjectId
from datetime import datetime

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
def dashboard():
    """Handle dashboard view"""
    if 'user_id' not in session:
        print("user not found")
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    try:
        db = get_db()
        # Get user info from Login collection
        user = db['Login'].find_one({'_id': ObjectId(session['user_id'])})
        if not user:
            flash('User not found', 'error')
            return redirect(url_for('login.login'))
        
        # Get user's profile info including photo and skills/categories
        profile = db['Profiles'].find_one({'user_id': session['user_id']}) or {}
        profile_photo = profile.get('profile_photo', '')
        skills = profile.get('skills', [])  # Get skills list
        categories = profile.get('categories', [])  # Get categories list
        
        # Get user's reviews
        all_reviews = list(db['Reviews'].find({'provider_id': session['user_id']}))
        total_reviews = len(all_reviews)
        
        # Calculate average rating with default value
        avg_rating = 0
        if total_reviews > 0:
            avg_rating = sum(review.get('rating', 0) for review in all_reviews) / total_reviews
        
        # Get rating distribution with defaults
        rating_distribution = {
            '5': 0, '4': 0, '3': 0, '2': 0, '1': 0
        }
        if total_reviews > 0:
            for rating in range(1, 6):
                rating_distribution[str(rating)] = len([r for r in all_reviews if r.get('rating') == rating])
        
        # Get recent reviews with user info
        recent_reviews = list(db['Reviews'].aggregate([
            {
                '$match': {'provider_id': session['user_id']}
            },
            {
                '$lookup': {
                    'from': 'Profiles',
                    'localField': 'user_id',
                    'foreignField': 'user_id',
                    'as': 'reviewer'
                }
            },
            {'$sort': {'created_at': -1}},
            {'$limit': 5}
        ]))
        
        # Get active projects count
        active_projects = db['Bookings'].count_documents({
            'provider_id': session['user_id'],
            'status': 'accepted'
        })
        
        # Get total unique clients
        total_clients = len(set(
            booking['user_id'] for booking in 
            db['Bookings'].find({'provider_id': session['user_id']})
        ))
        
        # Get recent activities
        activities = list(db['Activities'].find({
            'user_id': session['user_id']
        }).sort('created_at', -1).limit(3))

        # Get upcoming schedule
        schedule_items = list(db['Schedule'].find({
            'user_id': session['user_id'],
            'date': {'$gte': datetime.now()}
        }).sort('date', 1).limit(3))

        return render_template('dashboard.html',
                             first_name=user.get('first_name', ''),
                             last_name=user.get('last_name', ''),
                             tagline=profile.get('tagline', 'Add your tagline'),
                             profile_photo=profile_photo,
                             skills=skills,  # Pass skills to template
                             categories=categories,  # Pass categories to template
                             avg_rating=round(avg_rating, 1),
                             active_projects=active_projects,
                             total_clients=total_clients,
                             rating_distribution=rating_distribution,
                             rating_distribution_sum=sum(rating_distribution.values()),
                             recent_reviews=recent_reviews,
                             activities=activities,
                             schedule_items=schedule_items)
        
    except Exception as e:
        print(f"Dashboard error: {e}")  # For debugging
        flash('An error occurred while loading the dashboard', 'error')
        return redirect(url_for('hi.home'))

@dashboard_bp.route('/dashboard/analytics')
def analytics():
    """View detailed analytics"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    # Add analytics logic here
    return render_template('analytics.html')

@dashboard_bp.route('/dashboard/settings')
def settings():
    """View and update settings"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    # Add settings logic here
    return render_template('settings.html') 