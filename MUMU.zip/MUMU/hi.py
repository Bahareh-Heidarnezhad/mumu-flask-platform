from flask import Blueprint, render_template, request, flash, redirect, url_for, session
from db import get_db
from bson import ObjectId

hi_bp = Blueprint('hi', __name__)

@hi_bp.route('/hi')
def home():
    """Main route for the authenticated user's home page"""
    if 'user_id' not in session:
        return redirect(url_for('login.login'))
        
    categories = [
        {'icon': 'bi-camera', 'name': 'Photography'},
        {'icon': 'bi-palette', 'name': 'Graphic and Design'},
        {'icon': 'bi-brush', 'name': 'Beauty'},
        {'icon': 'bi-egg-fried', 'name': 'Food and Catering'},
        {'icon': 'bi-briefcase', 'name': 'Business'},
        {'icon': 'bi-people', 'name': 'Baby Sitting'},
        {'icon': 'bi-house', 'name': 'Cleaning'}
    ]
    
    try:
        db = get_db()
        # Get search query
        search_query = request.args.get('search', '').strip()
        
        if search_query:
            # Search for profiles with matching skills
            profiles = list(db['Profiles'].find({
                '$or': [
                    {'skills': {'$regex': search_query, '$options': 'i'}},
                    {'categories': {'$regex': search_query, '$options': 'i'}}
                ]
            }))
            
            # Calculate ratings
            for profile in profiles:
                reviews = list(db['Reviews'].find({'provider_id': profile.get('user_id')}))
                if reviews:
                    avg_rating = sum(review.get('rating', 0) for review in reviews) / len(reviews)
                    profile['rating'] = round(avg_rating, 1)
                else:
                    profile['rating'] = 0
        else:
            profiles = []
            
        # Get top rated professionals
        all_profiles = list(db['Profiles'].find())
        for profile in all_profiles:
            reviews = list(db['Reviews'].find({'provider_id': profile.get('user_id')}))
            if reviews:
                avg_rating = sum(review.get('rating', 0) for review in reviews) / len(reviews)
                profile['rating'] = round(avg_rating, 1)
            else:
                profile['rating'] = 0
                
        top_professionals = sorted(all_profiles, key=lambda x: x.get('rating', 0), reverse=True)[:3]
        
    except Exception as e:
        print(f"Error: {e}")
        profiles = []
        top_professionals = []
    
    return render_template('hi.html', 
                         categories=categories,
                         professionals=top_professionals,
                         profiles=profiles,
                         search_query=search_query if 'search_query' in locals() else '')

@hi_bp.route('/hi/search')
def search():
    """Route for handling search functionality"""
    return redirect(url_for('hi.home', search=request.args.get('q', '')))

@hi_bp.route('/hi/messages')
def messages():
    """Route for messages page"""
    return redirect(url_for('message.messages'))

@hi_bp.route('/hi/notifications')
def notifications():
    """Route for notifications"""
    return redirect(url_for('notification.notifications'))

@hi_bp.route('/hi/dashboard')
def dashboard():
    """Route for user dashboard"""
    return redirect(url_for('dashboard.dashboard'))

@hi_bp.route('/hi/contact/<professional_name>')
def contact_professional(professional_name):
    """Route for handling contact button clicks"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
        
    flash(f'Contact request sent to {professional_name}', 'success')
    return redirect(url_for('hi.home')) 