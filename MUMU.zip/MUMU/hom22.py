from flask import Blueprint, render_template, request, flash, redirect, url_for

hom22_bp = Blueprint('hom22', __name__)

@hom22_bp.route('/')
@hom22_bp.route('/hom22')
def home():
    """Main route for the home page"""
    categories = [
        {'icon': 'bi-camera', 'name': 'Photography'},
        {'icon': 'bi-palette', 'name': 'Graphic and Design'},
        {'icon': 'bi-brush', 'name': 'Beauty'},
        {'icon': 'bi-egg-fried', 'name': 'Food and Catering'},
        {'icon': 'bi-briefcase', 'name': 'Business'},
        {'icon': 'bi-people', 'name': 'Baby Sitting'},
        {'icon': 'bi-house', 'name': 'Cleaning'}
    ]
    
    top_professionals = [
        {
            'name': 'MARY THOMAS',
            'profession': 'Web designer',
            'quote': 'The best websites are those that are easy to use and hard to forget',
            'image': 'p1.jpg'
        },
        {
            'name': 'KHAN PATEL',
            'profession': 'Photographer',
            'quote': 'Through my lens, the world looks different, and I want to share that with you',
            'image': 'p3.jpg'
        },
        {
            'name': 'CHERRY RICHMOND',
            'profession': 'Cleaning',
            'quote': 'A tidy space can reduce stress and anxiety, making it easier to focus and relax.',
            'image': 'p2.jpg'
        }
    ]
    
    about_links = [
        'About MUMU',
        'Help/Support',
        'Terms of service',
        'Invite a friend',
        'Community Hub',
        'FAQs',
        'Communities'
    ]
    
    return render_template('hom22.html',
                         categories=categories,
                         professionals=top_professionals,
                         about_links=about_links)

@hom22_bp.route('/search')
def search():
    """Route for handling search functionality"""
    query = request.args.get('q', '')
    # Add search logic here
    return render_template('hom22.html', search_query=query)

@hom22_bp.route('/contact/<professional_name>')
def contact_professional(professional_name):
    """Route for handling contact button clicks"""
    flash(f'Contact request sent to {professional_name}', 'success')
    return redirect(url_for('hom22.home'))

@hom22_bp.route('/explore')
def explore():
    """Route for the explore section"""
    return redirect(url_for('hom22.home', _anchor='explore'))

@hom22_bp.route('/about')
def about():
    """Route for the about section"""
    return redirect(url_for('hom22.home', _anchor='about'))

@hom22_bp.route('/communities')
def communities():
    """Route for the communities section"""
    return redirect(url_for('hom22.home', _anchor='communities')) 