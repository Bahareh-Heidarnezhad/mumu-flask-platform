from flask import Blueprint, render_template, request, flash, redirect, url_for, session, jsonify
from db import get_db
from datetime import datetime
from bson import ObjectId

message_bp = Blueprint('message', __name__)

@message_bp.route('/messages')
def messages():
    """Display user's messages/conversations"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    try:
        db = get_db()
        user = db['Login'].find_one({'_id': ObjectId(session['user_id'])})
        profile = db['Profiles'].find_one({'user_id': session['user_id']}) or {}
        
        # Get conversations with user info
        conversations = list(db['Conversations'].aggregate([
            {
                '$match': {
                    '$or': [
                        {'user1_id': session['user_id']},
                        {'user2_id': session['user_id']}
                    ]
                }
            },
            {
                '$lookup': {
                    'from': 'Profiles',
                    'localField': 'user2_id',
                    'foreignField': 'user_id',
                    'as': 'other_user'
                }
            },
            {
                '$sort': {'last_message_time': -1}
            }
        ]))
        
        # Get chat requests
        chat_requests = list(db['ChatRequests'].aggregate([
            {
                '$match': {
                    'recipient_id': session['user_id'],
                    'status': 'pending'
                }
            },
            {
                '$lookup': {
                    'from': 'Profiles',
                    'localField': 'sender_id',
                    'foreignField': 'user_id',
                    'as': 'sender'
                }
            }
        ]))
        
        # Process chat requests to get sender info
        for request in chat_requests:
            sender = request['sender'][0] if request['sender'] else {}
            request['sender_name'] = f"{sender.get('first_name', '')} {sender.get('last_name', '')}".strip()
            request['sender_photo'] = sender.get('profile_photo')
        
        # Process conversations to get other user's info
        for conv in conversations:
            other_user = conv['other_user'][0] if conv['other_user'] else {}
            conv['other_user_name'] = f"{other_user.get('first_name', '')} {other_user.get('last_name', '')}".strip()
            conv['other_user_photo'] = other_user.get('profile_photo')
        
        return render_template('messages.html',
                             first_name=user.get('first_name', ''),
                             last_name=user.get('last_name', ''),
                             profile_photo=profile.get('profile_photo'),
                             conversations=conversations,
                             chat_requests=chat_requests)
                             
    except Exception as e:
        print(f"Messages error: {e}")
        flash('An error occurred while loading messages', 'error')
        return redirect(url_for('hi.home'))

@message_bp.route('/conversation/<user_id>')
def conversation(user_id):
    """Display a specific conversation"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    db = get_db()
    
    # Get or create conversation
    conversation = db['Conversations'].find_one({
        '$or': [
            {'user1_id': session['user_id'], 'user2_id': user_id},
            {'user1_id': user_id, 'user2_id': session['user_id']}
        ]
    })
    
    if not conversation:
        conversation_id = db['Conversations'].insert_one({
            'user1_id': session['user_id'],
            'user2_id': user_id,
            'created_at': datetime.now(),
            'last_message_time': datetime.now()
        }).inserted_id
    else:
        conversation_id = conversation['_id']
    
    # Get messages
    messages = db['Messages'].find({
        'conversation_id': conversation_id
    }).sort('created_at', 1)
    
    # Get other user's profile
    other_user = db['Profiles'].find_one({'user_id': user_id})
    
    return render_template('conversation.html', 
                         messages=messages, 
                         other_user=other_user,
                         conversation_id=conversation_id)

@message_bp.route('/send-message', methods=['POST'])
def send_message():
    """Handle sending a new message"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    conversation_id = request.form.get('conversation_id')
    message_text = request.form.get('message')
    
    if not all([conversation_id, message_text]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        db = get_db()
        
        # Insert new message
        new_message = {
            'conversation_id': ObjectId(conversation_id),
            'sender_id': session['user_id'],
            'message': message_text,
            'created_at': datetime.now()
        }
        db['Messages'].insert_one(new_message)
        
        # Update conversation last message time
        db['Conversations'].update_one(
            {'_id': ObjectId(conversation_id)},
            {'$set': {'last_message_time': datetime.now()}}
        )
        
        return jsonify({
            'success': True,
            'message': 'Message sent successfully'
        })
        
    except Exception as e:
        return jsonify({'error': 'Failed to send message'}), 500

@message_bp.route('/get-messages/<conversation_id>')
def get_messages(conversation_id):
    """Get messages for a conversation (for AJAX updates)"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    try:
        db = get_db()
        messages = list(db['Messages']
            .find({'conversation_id': ObjectId(conversation_id)})
            .sort('created_at', 1))
        
        # Convert ObjectId to string for JSON serialization
        for message in messages:
            message['_id'] = str(message['_id'])
            message['conversation_id'] = str(message['conversation_id'])
            message['created_at'] = message['created_at'].isoformat()
        
        return jsonify({
            'success': True,
            'messages': messages
        })
        
    except Exception as e:
        return jsonify({'error': 'Failed to fetch messages'}), 500 

def send_system_message(user_id, message_text):
    """Send a system message to a user"""
    try:
        db = get_db()
        
        # Find or create system conversation
        conversation = db['Conversations'].find_one({
            'user_id': user_id,
            'is_system': True
        })
        
        if not conversation:
            conversation_id = db['Conversations'].insert_one({
                'user_id': user_id,
                'is_system': True,
                'created_at': datetime.now()
            }).inserted_id
        else:
            conversation_id = conversation['_id']
        
        # Add message
        new_message = {
            'conversation_id': conversation_id,
            'message': message_text,
            'is_system': True,
            'created_at': datetime.now()
        }
        
        db['Messages'].insert_one(new_message)
        
        # Update conversation last message time
        db['Conversations'].update_one(
            {'_id': conversation_id},
            {'$set': {'last_message_time': datetime.now()}}
        )
        
        return True
        
    except Exception as e:
        print(f"Error sending system message: {e}")
        return False 