from flask import Blueprint, request, render_template, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash
from db import get_db

signup_bp = Blueprint('signup', __name__)

# Route for loading the signup page
@signup_bp.route('/signup', methods=['GET'])
def signup_page():
    return render_template('signup.html')

# Route for handling the form submission
@signup_bp.route('/signup/submit', methods=['POST'])
def signup_submit():
    print("signup submission route called")
    
    # Get JSON data from request
    data = request.get_json()
    
    username = data.get('signupUsername')
    first_name = data.get('firstName')
    last_name = data.get('lastName')
    student_email = data.get('studentEmail')
    personal_email = data.get('personalEmail')
    password = data.get('signupPassword')
    confirm_password = data.get('confirmPassword')

    # Basic validation
    if password != confirm_password:
        return jsonify({
            'success': False,
            'message': 'Passwords do not match!'
        })

    db = get_db()
    login_collection = db['Login']
    
    # Check if username already exists
    if login_collection.find_one({'username': username}):
        return jsonify({
            'success': False,
            'message': 'Username already exists!'
        })

    # Check if student email already exists
    if login_collection.find_one({'student_email': student_email}):
        return jsonify({
            'success': False,
            'message': 'Student email already registered!'
        })

    # Create new user
    new_user = {
        'username': username,
        'first_name': first_name,
        'last_name': last_name,
        'student_email': student_email,
        'personal_email': personal_email,
        'password': generate_password_hash(password)
    }

    try:
        login_collection.insert_one(new_user)
        return jsonify({
            'success': True,
            'message': 'Registration successful! Please login.',
            'redirect': url_for('login.login')
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'An error occurred during registration.'
        }) 