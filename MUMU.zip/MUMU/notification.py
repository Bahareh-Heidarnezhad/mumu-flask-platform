from flask import Blueprint, render_template, request, flash, redirect, url_for, session, jsonify
from db import get_db
from datetime import datetime
from bson import ObjectId

notification_bp = Blueprint('notification', __name__)

@notification_bp.route('/notifications')
def notifications():
    """Display user's notifications"""
    if 'user_id' not in session:
        flash('Please login first', 'error')
        return redirect(url_for('login.login'))
    
    db = get_db()
    notifications_collection = db['Notifications']
    
    # Get user's notifications sorted by date
    notifications = list(notifications_collection.find(
        {'user_id': session['user_id']}
    ).sort('created_at', -1))
    
    # Mark notifications as read
    notifications_collection.update_many(
        {
            'user_id': session['user_id'],
            'read': False
        },
        {'$set': {'read': True}}
    )
    
    return render_template('notifications.html', notifications=notifications)

@notification_bp.route('/notifications/unread-count')
def get_unread_count():
    """Get count of unread notifications"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    db = get_db()
    count = db['Notifications'].count_documents({
        'user_id': session['user_id'],
        'read': False
    })
    
    return jsonify({'count': count})

@notification_bp.route('/create-notification', methods=['POST'])
def create_notification():
    """Create a new notification"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    user_id = request.form.get('user_id')
    notification_type = request.form.get('type')
    message = request.form.get('message')
    
    if not all([user_id, notification_type, message]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        db = get_db()
        notifications_collection = db['Notifications']
        
        new_notification = {
            'user_id': user_id,
            'type': notification_type,
            'message': message,
            'read': False,
            'created_at': datetime.now()
        }
        
        result = notifications_collection.insert_one(new_notification)
        
        return jsonify({
            'success': True,
            'notification_id': str(result.inserted_id)
        })
        
    except Exception as e:
        return jsonify({'error': 'Failed to create notification'}), 500

@notification_bp.route('/notifications/delete/<notification_id>', methods=['DELETE'])
def delete_notification(notification_id):
    """Delete a notification"""
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    try:
        db = get_db()
        result = db['Notifications'].delete_one({
            '_id': ObjectId(notification_id),
            'user_id': session['user_id']
        })
        
        if result.deleted_count == 0:
            return jsonify({'error': 'Notification not found'}), 404
        
        return jsonify({'success': True})
        
    except Exception as e:
        return jsonify({'error': 'Failed to delete notification'}), 500

def create_system_notification(user_id, message, notification_type='system'):
    """Helper function to create system notifications"""
    try:
        db = get_db()
        notifications_collection = db['Notifications']
        
        new_notification = {
            'user_id': user_id,
            'type': notification_type,
            'message': message,
            'read': False,
            'created_at': datetime.now()
        }
        
        notifications_collection.insert_one(new_notification)
        return True
        
    except Exception as e:
        print(f"Error creating system notification: {e}")
        return False 